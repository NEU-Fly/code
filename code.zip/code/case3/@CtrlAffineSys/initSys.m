function initSys(obj, symbolic_x, symbolic_f, symbolic_g, symbolic_cbf, symbolic_clf, pos, obs)
% global SIZE
    if isempty(symbolic_x) || isempty(symbolic_f) || isempty(symbolic_g)
        error('x, f, g is empty. Create a class function defineSystem and define your dynamics with symbolic expression.');
    end

    if ~isa(symbolic_f, 'sym')  % �ж��ǲ���sym�Ķ���
        f = sym(symbolic_f);    % ���Ƿ��ű�����ʱ�����
    else
        f = symbolic_f;
    end
    if ~isa(symbolic_g, 'sym')
        g = sym(symbolic_g);
    else
        g = symbolic_g;
    end

    x = symbolic_x;  
    obj.xdim = size(x, 1);
    obj.udim = size(g, 2);
    obj.f = matlabFunction(f, 'vars', {x}); % �����ű���ʽת��Ϊ�������
    obj.g = matlabFunction(g, 'vars', {x});            

    % CBF.
    if ~isempty(symbolic_cbf)
        dcbf = simplify(jacobian(symbolic_cbf, symbolic_x));
        lf_cbf = dcbf * f;
        lg_cbf = dcbf * g;        
        obj.cbf = matlabFunction(symbolic_cbf, 'vars', {x,obs});
        obj.lf_cbf = matlabFunction(lf_cbf, 'vars', {x,obs});
        obj.lg_cbf = matlabFunction(lg_cbf, 'vars', {x,obs});
    end

    % CLF.    
    if ~isempty(symbolic_clf)
        dclf = simplify(jacobian(symbolic_clf, symbolic_x));
        lf_clf = dclf * f;
        lg_clf = dclf * g;
        obj.clf = matlabFunction(symbolic_clf,'vars',{x,pos});                       
        obj.lf_clf = matlabFunction(lf_clf,'vars',{x,pos});
        obj.lg_clf = matlabFunction(lg_clf,'vars',{x,pos});        
    end
end