function plot_state(t, xs)

figure('name','Positon')
h_position = plot(t, xs(:,1),t, xs(:,2),'-','LineWidth',2);
legend(h_position,'y','z');
grid on;
xlabel('$t(s)$','interpret','latex','fontsize',12)
ylabel('$Position(m)$','interpret','latex','fontsize',12)

figure('name','Phi')
plot(t, xs(:,3),'-','LineWidth',2)
grid on;
xlabel('$t(s)$','interpret','latex','fontsize',12)
ylabel('$\Phi(rad)$','interpret','latex','fontsize',12)

figure('name','Velocity')
h_velocity = plot(t, xs(:,4),t, xs(:, 5),'-','LineWidth',2);
legend(h_velocity,'v_y','v_z');
grid on;
xlabel('$t(s)$','interpret','latex','fontsize',12)
ylabel('$Velocity(m/s)$','interpret','latex','fontsize',12)

figure('name','Angular Velocity')
plot(t, xs(:, 6),'-','LineWidth',2)
grid on;
xlabel('$t(s)$','interpret','latex','fontsize',12)
ylabel('$Angular Velocity(rad/s)$','interpret','latex','fontsize',12)

end