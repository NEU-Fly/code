dis= zeros(total_k,1);

for i =1:total_k
  dis(i) = (xs(i,1)-Oy(i))^2 + (xs(i,2)-Oz(i))^2 - params.r_o^2;  
end

fff = figure('Name','Input','Position',[500 250 600 120]);

tiledlayout(1,1,'Padding', 'none','TileSpacing', 'none');
nexttile;
plot(ts(1:end-1), dis,'-','LineWidth',2);
xlabel('$t(s)$','interpret','latex','fontsize',12);
ylabel('$d(p,o)(m)$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','Ygrid','on','Xtick',0:10:ts(end));
aaax = axes(fff);
set(aaax, 'Position', [0.19 0.6 0.2 0.3],'Ylim',[2 4],'Ytick',[2:0.5:4],'Xlim',[13 14],'Xtick',[13:0.5:14],'box','on','Xgrid','on','Ygrid','on')
plot(aaax, ts(650:700), dis(650:700),'-','LineWidth',2);
