classdef Quadrotor2D < CtrlAffineSys
   methods
       function [x, f, g, pos,obs] = defineSystem(obj, params)
            syms p_y p_z phi v_y v_z w;  % �������״̬����
            syms pos_y pos_z theta vel_y vel_z omega o_y o_z;
            x = [p_y; p_z; phi; v_y; v_z; w];
            pos = [pos_y; pos_z; theta; vel_y; vel_z; omega];
            obs = [o_y; o_z];
            g = params.g;
            m = params.m;
            J = params.J;
            A = [0 0    0      1 0 0;
                 0 0    0      0 1 0;
                 0 0    0      0 0 1;
                 0 0   -g      0 0 0;
                 0 0    0      0 0 0;
                 0 0    0      0 0 0];
            B = [   0   0; 
                    0   0; 
                    0   0; 
                    0   0; 
                   1/m  0;
                    0  1/J];
            
            f = A * x; 
            g = B;    
       end
   
       function clf = defineClf(~, params, symbolic_state, pos)
            PHI=pi/2; 
           
            g = params.g;
            m = params.m;
            J = params.J;
         
            A = [0 0    0      1 0 0;
                 0 0    0      0 1 0;
                 0 0    0      0 0 1;
                 0 0   -g      0 0 0;
                 0 0    0      0 0 0;
                 0 0    0      0 0 0];
            B = [   0   0; 
                    0   0; 
                    0   0; 
               -PHI/m   0; 
                   1/m  0;
                    0  1/J];         
            Q = eye(size(A));
            R = eye(size(B,2));
                        
            x =symbolic_state;
            e = x - [pos(1); pos(2); pos(3); pos(4); pos(5); pos(6)];
            [~,K] = lqr(A,B,Q,R);  
            clf = e' * K * e;  
       end
        
       function cbf = defineCbf(~, params, symbolic_state, obs)
            x = symbolic_state;
             
            r_o = params.r_o;      % �ϰ���뾶
            distance = (x(1) - obs(1))^2 + (x(2) - obs(2))^2 - r_o^2;
            derivDistance = 2*(x(1)-obs(1))*x(4) + 2*(x(2)-obs(2))*x(5);
            del = 70*exp(-1*distance+1);  % delta ������
            cbf = derivDistance + distance - del;
       end
   end
end
