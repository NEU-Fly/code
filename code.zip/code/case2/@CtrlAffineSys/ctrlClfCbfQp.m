function [U, alpha_val, beta_val, B, V, feas] = ctrlClfCbfQp(obj, x, u_ref)
global Target_State SIZE;          
    if nargin < 3
        u_ref = zeros(obj.udim, 1);
    end

    Umin = obj.params.u_min;
    Umax = obj.params.u_max;
    alpha_slack = obj.params.weight.alpha_slack;
    beta_slack = obj.params.weight.beta_slack;
    alpha_ref = obj.params.alpha_ref;
    beta_ref = obj.params.beta_ref;
    V = obj.clf(x,Target_State);
    LfV = obj.lf_clf(x,Target_State);
    LgV = obj.lg_clf(x,Target_State);
    
    for i = 1:SIZE
        B{i,1} = obj.cbf{i}(x);
        LfB{i,1} = obj.lf_cbf{i}(x);
        LgB{i,1} = obj.lg_cbf{i}(x);
    end     

   %% QP���
    u = sdpvar(obj.udim,1); % ���߱���
    alpha = sdpvar(1,1);
    beta = sdpvar(1,1);
   %% Լ��  
    Constraints = [];
    % CLFԼ��
    Constraints = [Constraints; LfV + LgV*u + alpha*V <= 0];  
    % CBFԼ��
    for i = 1:SIZE 
        Constraints = [Constraints; cell2mat(LfB(i,1))+cell2mat(LgB(i,1))*u ...
                       + beta*cell2mat(B(i,1)) >= 0];
    end
    Constraints = [Constraints; beta>=0]; 
    % ��������Լ��
    Constraints = [Constraints; Umin <= u <= Umax];
    %% �ɱ�����
    H = obj.params.weight.input * eye(obj.udim);
%     Objective = 0.5*((u-u_ref)'*H*(u-u_ref)) + alpha_slack*(alpha-alpha_ref)^2+beta_slack*(beta-beta_ref)^2;
    Objective = 0.5*((u)'*H*(u)) + alpha_slack*(alpha)^2+beta_slack*(beta)^2;
    Options = sdpsettings('verbose',0,'solver','quadprog');
    sol = solvesdp(Constraints,Objective,Options);

    if sol.problem == 0
        U = value(u);
        alpha_val = value(alpha);
        beta_val = value(beta);
        feas = 1;
    else
        feas = 0;           
        disp('QP���ɽ�');
    end          
end