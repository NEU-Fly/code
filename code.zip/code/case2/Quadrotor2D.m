classdef Quadrotor2D < CtrlAffineSys
   methods
       function [x, f, g, POS] = defineSystem(obj, params)
            syms p_y p_z phi v_y v_z w ;  % �������״̬����
            syms pos_y pos_z vel_y vel_z;             % �������Ŀ��λ��
            x = [p_y; p_z; phi; v_y; v_z; w];
            POS = [pos_y; pos_z; vel_y; vel_z];
            
            g = params.g;
            m = params.m;
            J = params.J;
            A = [0 0    0      1 0 0;
                 0 0    0      0 1 0;
                 0 0    0      0 0 1;
                 0 0   -g      0 0 0;
                 0 0    0      0 0 0;
                 0 0    0      0 0 0];
            B = [   0   0; 
                    0   0; 
                    0   0; 
                    0   0; 
                   1/m  0;
                    0  1/J];
            
            f = A * x; 
            g = B;    
       end
   
       function clf = defineClf(~, params, symbolic_state, POS)
            PHI = pi/2;
            g = params.g;
            m = params.m;
            J = params.J; 
         
            A = [0 0    0      1 0 0;
                 0 0    0      0 1 0;
                 0 0    0      0 0 1;
                 0 0   -g      0 0 0;
                 0 0    0      0 0 0;
                 0 0    0      0 0 0];
            B = [   0   0; 
                    0   0; 
                    0   0; 
               -PHI/m   0; 
                   1/m  0;
                    0  1/J]; 
            % LQR
            Q = eye(size(A));
            R = eye(size(B,2));
            [~,K] = lqr(A,B,Q,R);  
            
            x =symbolic_state;
            e = x - [POS(1); POS(2); 0; POS(3); POS(4); 0];
            clf = e' * K * e;  
       end
        
       function cbf = defineCbf(~, params, symbolic_state)
            global SIZE
            x = symbolic_state;
           
            for i = 1:SIZE   
                p_o = params.p_o(i,:); % �ϰ�������λ��
                r_o = params.r_o;      % �ϰ���뾶
                distance = (x(1) - p_o(1))^2 + (x(2) - p_o(2))^2 - r_o^2;
                derivDistance = 2*(x(1)-p_o(1))*x(4) + 2*(x(2)-p_o(2))*x(5);
                del =  15*exp(-3*distance+2);  % delta ������
                cbf(i,1) = derivDistance + distance -del;
            end
       end
   end
end
