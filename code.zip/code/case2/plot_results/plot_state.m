clc;
figure('Name','State','position',[488,342,560,420]);
tiledlayout(5,1,'Padding', 'none','TileSpacing', 'none');
nexttile;
plot(ts, xs(:,1),'-','LineWidth',2);
ylabel('$x(m)$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','Ygrid','on','Xtick',0:10:ts(end));

nexttile;
plot(ts, xs(:,3),'-','LineWidth',2);
ylabel('$v_x(m/s)$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','ygrid','on','xtick',0:10:ts(end));

nexttile;
plot(ts, xs(:,2),'-','LineWidth',2);
ylabel('$y(m)$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','ygrid','on','xtick',0:10:ts(end));

nexttile;
plot(ts, xs(:, 4),'-','LineWidth',2);
ylabel('$v_y(m/s)$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','ygrid','on','xtick',0:10:ts(end));

nexttile;
plot(ts, sqrt(xs(:, 3).^2 + xs(:, 4).^2),'-','LineWidth',2);
xlabel('$t(s)$','interpret','latex','fontsize',12);
ylabel('$v(m/s)$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','ygrid','on','xtick',0:10:ts(end));
