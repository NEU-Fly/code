figure('Name','a b','Position',[500 250 600 210]);
tiledlayout(2,1,'Padding', 'none','TileSpacing', 'none');
nexttile;
plot(ts(1:end-1), alpha_value,'-','LineWidth',2);
ylabel('$\gamma$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','Ygrid','on','Xtick',0:10:ts(end));

nexttile;
plot(ts(1:end-1), beta_value,'-','LineWidth',2);
xlabel('$t(s)$','interpret','latex','fontsize',12);
ylabel('$\lambda$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','Ygrid','on','Xtick',0:10:ts(end));