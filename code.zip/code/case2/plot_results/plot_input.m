figure('Name','Input','Position',[500 250 600 210]);
tiledlayout(2,1,'Padding', 'none','TileSpacing', 'none');
nexttile;
plot(ts(1:end-1), us(:,1),'-','LineWidth',2);
ylabel('$F(N)$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','Ygrid','on','Xtick',0:10:ts(end));

nexttile;
plot(ts(1:end-1), us(:,2),'-','LineWidth',2);
xlabel('$t(s)$','interpret','latex','fontsize',12);
ylabel('$M(N\cdot m)$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','Ygrid','on','Xtick',0:10:ts(end));