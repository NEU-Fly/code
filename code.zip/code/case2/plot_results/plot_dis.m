dis1= zeros(total_k,1);
dis2= zeros(total_k,1);
for i =1:total_k
  dis1(i) = xs(i,1)^2 + (xs(i,2)-3.5)^2 - params.r_o^2;  
end

for i =1:total_k
  dis2(i) = xs(i,1)^2 + (xs(i,2)+3.5)^2 - params.r_o^2;  
end

fff = figure('Name','Input','Position',[500 250 600 210]);

tiledlayout(2,1,'Padding', 'none','TileSpacing', 'none');
nexttile;
plot(ts(1:end-1), dis1,'-','LineWidth',2);
ylabel('$d(p,o_1)(m)$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','Ygrid','on','Xtick',0:10:ts(end));
nexttile;
plot(ts(1:end-1), dis2,'-','LineWidth',2);
xlabel('$t(s)$','interpret','latex','fontsize',12);
ylabel('$d(p,o_2)(m)$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','Ygrid','on','Xtick',0:10:ts(end));


aaa1 = axes(fff);
set(aaa1, 'Position', [0.19 0.3 0.2 0.2],'Xlim',[12 16],'Xtick',[12:1:16],'box','on','Xgrid','on','Ygrid','on')
plot(aaa1, ts(600:800), dis2(600:800),'-','LineWidth',2);

aaa2 = axes(fff);
set(aaa2, 'Position', [0.65 0.76 0.2 0.2],'Xlim',[44 50],'Xtick',[44:1:50],'box','on','Xgrid','on','Ygrid','on')
plot(aaa2, ts(2200:2500), dis1(2200:2500),'-','LineWidth',2);
