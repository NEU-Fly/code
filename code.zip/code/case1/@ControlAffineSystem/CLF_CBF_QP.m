function [U, gamma_val, lambda_val, B, V, feas] = CLF_CBF_QP(obj, x, u_ref)
    % Ŀ��״̬,�ϰ�λ��,�ϰ������
    global Target_State Obstacle_Position SIZE;
    if nargin < 3
        u_ref = zeros(obj.udim, 1);
    end
    % CLF,CBF,u �ĳ�����
    gamma_slack = obj.params.weight.gamma_slack;
    lambda_slack = obj.params.weight.lambda_slack;
    gamma_ref = obj.params.gamma_ref;
    lambda_ref = obj.params.lambda_ref;
    Umin = obj.params.u_min;
    Umax = obj.params.u_max;
    % CLF�����
    V = obj.clf(x,Target_State);
    LfV = obj.lf_clf(x,Target_State);
    LgV = obj.lg_clf(x,Target_State);
    % CBF�����
    for i = 1:SIZE
        B{i,1} = obj.cbf{i}(x,Obstacle_Position(2*i-1:2*i));% 2d,3d
        LfB{i,1} = obj.lf_cbf{i}(x,Obstacle_Position(2*i-1:2*i));
        LgB{i,1} = obj.lg_cbf{i}(x,Obstacle_Position(2*i-1:2*i));
    end

    %% QP���
    u = sdpvar(obj.udim,1); % ���߱���
    gamma = sdpvar(1,1);
    lambda = sdpvar(1,1);    
    % CLFԼ��
    Constraints = [LfV+LgV*u + gamma*V <= 0];
    for i = 1:SIZE   % CBFԼ��
        Constraints = [Constraints; cell2mat(LfB(i,1))+...
        cell2mat(LgB(i,1))*u + lambda*cell2mat(B(i,1)) >= 0; lambda>=0];
    end
    % ��������Լ��
    Constraints = [Constraints; Umin <= u <= Umax];
    % �ɱ�����
    H = obj.params.weight.input * eye(obj.udim);
    Objective = 0.5*((u-u_ref)'*H*(u-u_ref)) + gamma_slack*(gamma-gamma_ref)^2+lambda_slack*(lambda-lambda_ref)^2;
    Options = sdpsettings('verbose',0,'solver','quadprog');
    sol = solvesdp(Constraints,Objective,Options); % ���
    % QP��������Ϣ
    if sol.problem == 0
        U = value(u);
        gamma_val = value(gamma);
        lambda_val = value(lambda);
        feas = 1;
    else
        feas = 0;
        disp('QP������');
    end
end