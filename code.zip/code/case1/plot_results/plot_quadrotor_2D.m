function plot_quadrotor_2D(t,state,traj,obs_cen,obs_r,lim)
%% ��������������
position=state(:,1:2);
angle=state(:,3);
fig=figure('Name','Quadrotor_2D','NumberTitle','off','Position',[500 250 400 410]);
ax=axes;
axis equal;
if nargin<6
    lim=6;
end
set(ax,'looseinset',get(ax,'tightinset'),'nextplot','add','XGrid','on','YGrid','on',...
    'Xlim',[-lim lim],'Ylim',[-lim lim],'XTick',-lim:1:lim,'YTick',-lim:1:lim);
% �ϰ���켣
p2(1) = plot(ax,0,0,'-.r','LineWidth',1);
p2(2) = plot(ax,0,0,'-.r','LineWidth',1);
% ��ʼλ��
x0 = [-4.5; -1; 0; 0; 0; 0];
p4 = plot(ax,x0(1),x0(2),'Marker','p','Markersize',10, 'MarkerEdgeColor','k','MarkerFaceColor','k');
% �ϰ���
rect(1) = rectangle(ax,'Position',[0,0,0,0],'Curvature',[1,1],...
        'LineWidth',2,'EdgeColor',[1 0 0],'FaceColor',[1 0 0]); 
rect(2) = rectangle(ax,'Position',[0,0,0,0],'Curvature',[1,1],...
    'LineWidth',2,'EdgeColor',[1 0 0],'FaceColor',[1 0 0]); 
% �ο��켣
p1 = plot(ax,traj(:,1),traj(:,2),'--b','LineWidth',1);
% title(ax,'2D\_Quadrotor','Fontname', 'Times New Roman','FontSize',12);
xlabel(ax,'y(m)','interpreter','latex','Fontname', 'Times New Roman','FontSize',12);
ylabel(ax,'z(m)','interpreter','latex','Fontname', 'Times New Roman','FontSize',12);

Quadrotor.L = 0.5;     % ���۳���
Quadrotor.H = 0.2;     % ����߶�
Quadrotor.W = 0.15;    % �������뾶
%% ���幹���������Ĺؼ������
Quadrotor_Body = [Quadrotor.L            0      1;
                 -Quadrotor.L            0      1;
                  Quadrotor.L       Quadrotor.H 1;
                 -Quadrotor.L       Quadrotor.H 1;
           Quadrotor.L+Quadrotor.W  Quadrotor.H 1;
           Quadrotor.L-Quadrotor.W  Quadrotor.H 1;
          -Quadrotor.L+Quadrotor.W  Quadrotor.H 1;
          -Quadrotor.L-Quadrotor.W  Quadrotor.H 1;
                                 0            0 1]';  % ע��������ת��

h1 = plot(ax,0,0,'-b','LineWidth',2,'Marker','.','MarkerSize',4,'MarkerEdgeColor','b','MarkerFaceColor','b'); % ����
h2 = plot(ax,0,0,'-b','LineWidth',2);   % ���1
h3 = plot(ax,0,0,'-b','LineWidth',2);   % ���2
h4 = plot(ax,0,0,'-b','LineWidth',2);   % ������1
h5 = plot(ax,0,0,'-b','LineWidth',2);   % ������2
h6 = plot(ax,0,0,'Marker','.','MarkerSize',16,'MarkerEdgeColor','k','MarkerFaceColor','k');
line = plot(ax,0,0,'-k','LineWidth',2);   % �������켣
k=1;   
col = [0.8 0.8 1];
col1 = [1 0.8 0.8];
t1=text(ax,-0.35,0,'0');
text(ax,3.5,0,'o_2');
t2=text(ax,0,0,'o_1');
for i = 1:k:size(t)-1
    set(t1,'Position',[-0.35,0],'String', ['T:' num2str(0.02*(i-1))]);
    set(t2,'Position',[obs_cen(2*1-1,i),obs_cen(2*1,i)],'String', 'o_1');
    % ��ȡ������λ�ú���̬
    quadrotor_pos = position(i,:)';
    phi=angle(i);
    % 2D��ת����
    R = [cos(phi) -sin(phi);
         sin(phi) cos(phi)];
    % ͨ�����������ڻ�������ϵ�µĹؼ���任����������ϵ��
    % ���ڻ��������ڵ�������ϵ�µ���ʵ��̬
    wHb = [R quadrotor_pos;
           0   0  1];
    quadrotor_world = wHb * Quadrotor_Body; % [3x3][3x8]
    quadrotor_atti = quadrotor_world(1:2, :); 
    
    % ��������ͼ
    set(h1,'Xdata',quadrotor_atti(1,[1 2]), 'Ydata',quadrotor_atti(2,[1 2]));   % ����
    set(h2,'Xdata',quadrotor_atti(1,[1 3]), 'Ydata',quadrotor_atti(2,[1 3]));   % ���1
    set(h3,'Xdata',quadrotor_atti(1,[4 2]), 'Ydata',quadrotor_atti(2,[4 2]));   % ���2
    set(h4,'Xdata',quadrotor_atti(1,[5 6]), 'Ydata',quadrotor_atti(2,[5 6]));   % ������1
    set(h5,'Xdata',quadrotor_atti(1,[7 8]), 'Ydata',quadrotor_atti(2,[7 8]));   % ������2
    set(h6,'Xdata',quadrotor_atti(1,9), 'Ydata',quadrotor_atti(2,9)); 
    set(line,'Xdata',position(1:i,1),'Ydata',position(1:i,2));                  % �������켣
    set(p1,'Xdata',traj(1:i,1),'Ydata',traj(1:i,2));
    for  j = 1: size(obs_cen,1)/2
        set(p2(j),'Xdata',obs_cen(2*j-1,1:i),'Ydata',obs_cen(2*j,1:i));
        set(rect(j),'Position',[obs_cen(2*j-1,i)-obs_r, obs_cen(2*j,i)-obs_r, 2*obs_r, 2*obs_r]);
    end
    if i==701 || i==2301
        rectangle(ax,'Position',[obs_cen(1,i)-obs_r, obs_cen(2,i)-obs_r, 2*obs_r, 2*obs_r],'Curvature',[1,1],...
        'LineWidth',2,'EdgeColor',col1,'FaceColor',col1);  
        plot(ax,quadrotor_atti(1,[1 2]),quadrotor_atti(2,[1 2]),'-','color',col,'LineWidth',2,'Marker','.','MarkerSize',4,'MarkerEdgeColor',col,'MarkerFaceColor',col); % ����
        plot(ax,quadrotor_atti(1,[1 3]),quadrotor_atti(2,[1 3]),'-','color',col,'LineWidth',2);   % ���1
        plot(ax,quadrotor_atti(1,[4 2]),quadrotor_atti(2,[4 2]),'-','color',col,'LineWidth',2);   % ���2
        plot(ax,quadrotor_atti(1,[5 6]),quadrotor_atti(2,[5 6]),'-','color',col,'LineWidth',2);   % ������1
        plot(ax,quadrotor_atti(1,[7 8]),quadrotor_atti(2,[7 8]),'-','color',col,'LineWidth',2);   % ������2
        text(ax, obs_cen(2*1-1,i),obs_cen(2*1,i),'o_1','color',col);
        col = col-[0.2 0.2 0];
        col1 = col1-[0 0.2 0.2];
        
    end
% if i == 1
%     pause(2);
% end
    drawnow;
end
% p1=plot(ax,traj(:,1),traj(:,2),'--b','LineWidth',1);
 legend([p1 line p2(1) p4],{'�ο��켣','ʵ�ʹ켣','�ϰ���켣', '��ʼλ��'});

