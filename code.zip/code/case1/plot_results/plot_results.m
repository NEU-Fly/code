clc;
plot_quadrotor_2D(ts,xs,[Yd; Zd]',params.p_o,params.r_o);

      
      