
dis= zeros(total_k,1);
dis1= zeros(total_k,1);
for i =1:total_k
  dis(i) = (xs(i,1)-params.p_o(1,i))^2 + (xs(i,2)-params.p_o(2,i))^2 - params.r_o^2;  
end
for i =1:total_k
  dis1(i) = (xs(i,1)-params.p_o(3,i))^2 + (xs(i,2)-params.p_o(4,i))^2 - params.r_o^2;  
end

fff = figure('Name','Input','Position',[500 250 600 210]);
tiledlayout(2,1,'Padding', 'none','TileSpacing', 'none');
nexttile;
plot(ts(1:end-1), dis,'-','LineWidth',2);
ylabel('$d(p,o_1)(m)$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','Ygrid','on','Xtick',0:10:ts(end));

nexttile;
plot(ts(1:end-1), dis1,'-','LineWidth',2);
xlabel('$t(s)$','interpret','latex','fontsize',12);
ylabel('$d(p,o_2)(m)$','interpret','latex','fontsize',12);
set(gca,'Xlim',[0 ts(end)],'box','on','Xgrid','on','Ygrid','on','Xtick',0:10:ts(end));

aaa1 = axes(fff);
set(aaa1, 'Position', [0.21 0.79 0.2 0.2],'Xlim',[14.5 15.5],'Xtick',[14.5:0.5:15.5],'box','on','Xgrid','on','Ygrid','on')
plot(aaa1, ts(725:775), dis(725:775),'-','LineWidth',2);
