function F = cut(F)
F = setcutflag(F);