function F = set(varargin)
%SET OBSOLETE

disp('SET has been considered obsolete for many years, and the time has come...');
disp('Update your code. https://yalmip.github.io/tutorial/basics/');
error('Obsolete command')
