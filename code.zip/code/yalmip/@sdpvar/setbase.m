function X=getbase(X,B)
%SETBASE Internal function to set all base matrices

X.basis = B;
  
  
  
  
      