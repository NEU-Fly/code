function y=sqr(x)
y = x*x;